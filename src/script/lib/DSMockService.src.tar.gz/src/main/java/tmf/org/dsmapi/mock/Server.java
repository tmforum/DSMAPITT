package tmf.org.dsmapi.mock;

import java.net.InetSocketAddress;

import com.sun.net.httpserver.HttpServer;

public class Server {

    public static void main(String[] args) throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(Integer.valueOf(args[0])), 0);
        server.createContext("/listener", new Listener(args[1]));
        server.setExecutor(null); // creates a default executor
        server.start();
    }

}