package tmf.org.dsmapi.mock;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import tmf.org.dsmapi.mock.utils.Format;

import java.io.*;
import java.util.Date;

public class Listener implements HttpHandler {

    private static File logFile;

    public Listener(String responseFilePath) {
        if (logFile == null) {
            logFile = new File(responseFilePath);
        }
    }

    public synchronized void handle(HttpExchange t) throws IOException {

        String method = t.getRequestMethod();

        FileOutputStream logOutS = new FileOutputStream(logFile, true);
        String info = Format.toString(new Date()) + " --- START  --- " + method;
        //System.out.print(info);
        logOutS.write(info.getBytes());

        if (!"GET".equalsIgnoreCase(method)) {
            logOutS.write("\n".getBytes());
            InputStream bodyS = t.getRequestBody();
            byte[] buffer = new byte[256];
            int bytesRead = 0;
            while ((bytesRead = bodyS.read(buffer)) != -1) {
                logOutS.write(buffer, 0, bytesRead);
            }
        }

        info = "\n" + Format.toString(new Date()) + " --- FINITO --- \n\n";
        //System.out.print(info);
        logOutS.write(info.getBytes());
        logOutS.close();
        logOutS = null;
        System.gc();

        t.sendResponseHeaders(201, 0);
        t.getResponseBody().close();

    }
}
